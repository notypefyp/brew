# helloworld/__init__.py

from .hello import say_hello

__all__ = ["say_hello"]
