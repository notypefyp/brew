# helloworld/hello.py

def say_hello():
    """Выводит 'Hello, World!'."""
    print("Hello, World!")
